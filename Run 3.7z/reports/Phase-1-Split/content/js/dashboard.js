/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.98934556061134, "KoPercent": 0.010654439388655908};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.959440332061946, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.6731854893908282, 700, 5200, "Form Render"], "isController": false}, {"data": [0.9999945242384585, 500, 1500, "Form Render-21"], "isController": false}, {"data": [0.9944183286933503, 500, 1500, "OTP Validation"], "isController": false}, {"data": [0.9999890484769169, 500, 1500, "Form Render-20"], "isController": false}, {"data": [0.9999890484769169, 500, 1500, "Form Render-18"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-19"], "isController": false}, {"data": [1.0, 500, 1500, "Form Render-16"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-17"], "isController": false}, {"data": [1.0, 500, 1500, "JSR223 Sampler"], "isController": false}, {"data": [0.9946367113683461, 500, 1500, "Customer Information"], "isController": false}, {"data": [0.9937505133751334, 2300, 6600, "Final Submit"], "isController": false}, {"data": [0.9947739326499129, 500, 1500, "Check Offer"], "isController": false}, {"data": [0.9994113556342848, 500, 1500, "Form Render-14"], "isController": false}, {"data": [1.0, 500, 1500, "Form Render-15"], "isController": false}, {"data": [0.9999863105961462, 500, 1500, "Form Render-12"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-13"], "isController": false}, {"data": [0.9999589317884385, 500, 1500, "Form Render-10"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-11"], "isController": false}, {"data": [0.5615311324422444, 500, 1500, "Form Render-0"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-1"], "isController": false}, {"data": [0.9999917863576877, 500, 1500, "Form Render-2"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-3"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-4"], "isController": false}, {"data": [1.0, 500, 1500, "Form Render-5"], "isController": false}, {"data": [1.0, 500, 1500, "Form Render-6"], "isController": false}, {"data": [0.9999972621192292, 500, 1500, "Form Render-7"], "isController": false}, {"data": [0.9999835727153754, 500, 1500, "Form Render-8"], "isController": false}, {"data": [1.0, 500, 1500, "Form Render-9"], "isController": false}, {"data": [0.9949480198245726, 500, 1500, "OTP Generation"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4711651, 502, 0.010654439388655908, 219.73096755256933, 1, 62015, 6.0, 222.0, 387.9500000000007, 1151.950000000008, 436.0603251592497, 50900.13278679731, 449.5530731158117], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Form Render", 182625, 9, 0.004928131416837783, 2104.0614702258854, 39, 36970, 577.0, 3579.7000000000044, 5967.600000000006, 11349.800000000032, 16.901845649152573, 25433.34583936269, 186.44597287656944], "isController": false}, {"data": ["Form Render-21", 182623, 0, 0.0, 35.59437748804859, 4, 1138, 6.0, 92.0, 97.0, 134.9900000000016, 16.90261166142576, 679.8572940745344, 8.45130583071288], "isController": false}, {"data": ["OTP Validation", 109555, 7, 0.006389484733695404, 266.21627493039676, 214, 61890, 304.0, 395.0, 494.0, 691.0, 10.144627731840696, 5.075439788432819, 10.887632963331368], "isController": false}, {"data": ["Form Render-20", 182623, 1, 5.475761541536389E-4, 43.09625841213823, 5, 1127, 7.0, 112.0, 116.0, 154.0, 16.902602274937014, 1132.4914596598724, 8.715356574538724], "isController": false}, {"data": ["Form Render-18", 182623, 2, 0.0010951523083072778, 25.86915120220336, 3, 330, 5.0, 65.0, 71.0, 114.0, 16.902675802711194, 19.534055754879223, 8.616308732004065], "isController": false}, {"data": ["Form Render-19", 182623, 0, 0.0, 25.767871516731052, 3, 1083, 5.0, 65.0, 69.0, 107.0, 16.902699269156763, 24.331048122320933, 8.632921599383776], "isController": false}, {"data": ["Form Render-16", 182623, 0, 0.0, 35.85228585665566, 4, 368, 6.0, 92.0, 96.0, 136.0, 16.90263043443452, 665.7178947317059, 8.517341117351771], "isController": false}, {"data": ["Form Render-17", 182623, 0, 0.0, 25.846361082667567, 3, 1089, 5.0, 65.0, 67.0, 109.9900000000016, 16.902663287300204, 13.244851571414198, 8.533864179232621], "isController": false}, {"data": ["JSR223 Sampler", 70, 0, 0.0, 3.2857142857142856, 1, 11, 2.0, 8.899999999999999, 10.0, 11.0, 0.010801373996494492, 0.0, 0.0], "isController": false}, {"data": ["Customer Information", 109541, 8, 0.007303201540975525, 264.6468536894885, 206, 61629, 303.0, 395.0, 494.0, 627.9700000000048, 10.1447225836374, 5.948397508316717, 10.095187805396982], "isController": false}, {"data": ["Final Submit", 73046, 445, 0.6092051583933412, 424.7131533554228, 205, 61786, 399.0, 641.0, 1156.0, 1544.9900000000016, 6.762704489274439, 12.207611330638443, 35.0256776998197], "isController": false}, {"data": ["Check Offer", 109547, 11, 0.01004135211370462, 268.29609208833193, 215, 61629, 303.0, 395.0, 494.0, 691.0, 10.144808489386, 5.007613597010964, 10.243878884790158], "isController": false}, {"data": ["Form Render-14", 182623, 1, 5.475761541536389E-4, 107.15731862908774, 13, 1350, 22.0, 287.0, 300.0, 326.0, 16.90225341783272, 8581.725306173617, 8.59963458079037], "isController": false}, {"data": ["Form Render-15", 182623, 0, 0.0, 26.24129490808921, 3, 305, 5.0, 65.0, 71.0, 113.0, 16.90267736713887, 143.0193688162827, 8.533871287901169], "isController": false}, {"data": ["Form Render-12", 182623, 2, 0.0010951523083072778, 26.717406898364466, 3, 1092, 5.0, 65.0, 74.0, 109.0, 16.902664851725564, 70.11508731583066, 8.616303149629164], "isController": false}, {"data": ["Form Render-13", 182623, 0, 0.0, 26.340340482852977, 3, 1086, 5.0, 65.0, 73.0, 108.0, 16.902689882570716, 24.623484862179673, 8.68243640452363], "isController": false}, {"data": ["Form Render-10", 182623, 2, 0.0010951523083072778, 95.67722028440996, 12, 932, 20.0, 243.0, 257.0, 284.0, 16.902445834992744, 6622.913281597148, 8.51715481970018], "isController": false}, {"data": ["Form Render-11", 182623, 0, 0.0, 27.04048778083789, 3, 1100, 5.0, 65.0, 76.0, 109.0, 16.902708655753237, 124.38337274965332, 8.61641984209296], "isController": false}, {"data": ["Form Render-0", 182623, 0, 0.0, 1925.2772980401962, 11, 36917, 173.0, 3424.0, 5829.650000000005, 11236.600000000064, 16.90242549801269, 2804.7343107265506, 7.147217031874506], "isController": false}, {"data": ["Form Render-1", 182623, 0, 0.0, 27.69966543096984, 3, 1111, 5.0, 65.0, 67.0, 98.0, 16.90261322584156, 156.27341226655741, 8.43480015469242], "isController": false}, {"data": ["Form Render-2", 182623, 0, 0.0, 53.8617917786919, 6, 635, 10.0, 129.0, 146.0, 187.0, 16.902494331065757, 1676.1097144852838, 8.401728139172336], "isController": false}, {"data": ["Form Render-3", 182623, 0, 0.0, 28.803869173105205, 3, 1072, 5.0, 65.0, 87.0, 127.0, 16.90263356327337, 148.59729331554954, 8.385290869280148], "isController": false}, {"data": ["Form Render-4", 182623, 0, 0.0, 29.471079765417766, 3, 1130, 5.0, 66.0, 93.0, 128.0, 16.90263512769323, 71.16575709160658, 8.533849961931054], "isController": false}, {"data": ["Form Render-5", 182623, 0, 0.0, 30.19989815083543, 3, 365, 5.0, 74.0, 105.0, 131.0, 16.90261322584156, 10.344943448483463, 8.451306612920781], "isController": false}, {"data": ["Form Render-6", 182623, 0, 0.0, 39.352606188705316, 3, 376, 6.0, 105.0, 141.0, 159.0, 16.90260383935108, 340.16059359592543, 8.45130191967554], "isController": false}, {"data": ["Form Render-7", 182623, 0, 0.0, 35.96714543075036, 3, 1101, 6.0, 86.0, 96.0, 128.9900000000016, 16.90261322584156, 377.98763866021454, 8.418293696464058], "isController": false}, {"data": ["Form Render-8", 182623, 2, 0.0010951523083072778, 53.45949305399662, 6, 557, 9.0, 129.0, 142.0, 176.0, 16.90255847146072, 1716.0817615396684, 8.517211577298779], "isController": false}, {"data": ["Form Render-9", 182623, 0, 0.0, 27.455391708601166, 3, 334, 5.0, 65.0, 76.0, 111.0, 16.902680495995096, 31.07224884415521, 8.682431582903732], "isController": false}, {"data": ["OTP Generation", 109561, 12, 0.01095280254835206, 271.59603326001167, 206, 62015, 304.0, 355.0, 451.0, 651.9900000000016, 10.144256191425812, 5.270500063238989, 10.444732265774539], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 434, 86.45418326693228, 0.009211208555132798], "isController": false}, {"data": ["503\/Service Unavailable", 12, 2.3904382470119523, 2.5468779415113724E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException\/Non HTTP response message: Connection reset", 2, 0.398406374501992, 4.244796569185621E-5], "isController": false}, {"data": ["502\/Bad Gateway", 1, 0.199203187250996, 2.1223982845928104E-5], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 10, 1.9920318725099602, 2.1223982845928105E-4], "isController": false}, {"data": ["503\/first byte timeout", 36, 7.171314741035856, 7.640633824534118E-4], "isController": false}, {"data": ["Assertion failed", 7, 1.3944223107569722, 1.4856787992149673E-4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4711651, 502, "400\/Bad Request", 434, "503\/first byte timeout", 36, "503\/Service Unavailable", 12, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 10, "Assertion failed", 7], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Form Render", 182625, 9, "Assertion failed", 7, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Connection reset", 2, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["OTP Validation", 109555, 7, "503\/first byte timeout", 6, "503\/Service Unavailable", 1, null, null, null, null, null, null], "isController": false}, {"data": ["Form Render-20", 182623, 1, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Form Render-18", 182623, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Customer Information", 109541, 8, "503\/Service Unavailable", 4, "503\/first byte timeout", 4, null, null, null, null, null, null], "isController": false}, {"data": ["Final Submit", 73046, 445, "400\/Bad Request", 434, "503\/first byte timeout", 6, "503\/Service Unavailable", 5, null, null, null, null], "isController": false}, {"data": ["Check Offer", 109547, 11, "503\/first byte timeout", 11, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Form Render-14", 182623, 1, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Form Render-12", 182623, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Form Render-10", 182623, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Form Render-8", 182623, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["OTP Generation", 109561, 12, "503\/first byte timeout", 9, "503\/Service Unavailable", 2, "502\/Bad Gateway", 1, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
